<!--===========================================================

	Add to Head, a WordPress Plugin
	Samuel H. Cohen, samuelhcohen.com
	The easiest way to add any content (CSS, Javascript, meta, 
	etc...) to the head section of every page of your 
	WordPress site.

	Add content (CSS, Javascript, meta, etc...) to this file 
	to include it in the <head>...</head> section of your 
	WordPress site. For example, you could include a style 
	like this:
	
		<style type="text/css">
			body {
				background-color: #666;
			}
		</style>
		
	Don't forget to put your content outside of this comment 
	block (duh!). Although, it would probably be best to 
	remove this whole dang thing before you go live (other-
	wise, this comment block will be outputted along with 
	your content).
		
============================================================-->
